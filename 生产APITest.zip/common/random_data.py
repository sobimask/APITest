import random
import string

randomdata = 'test' + ''.join(random.sample(string.ascii_letters + string.digits, 8))
# print(data)
